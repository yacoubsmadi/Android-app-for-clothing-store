package com.furqan.flutter_ecommerce_ui_kit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
